package p1;

public class JobClass {

	String city;
	String tech;
	
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getTech() {
		return tech;
	}

	public void setTech(String tech) {
		this.tech = tech;
	}

	public JobClass(String city, String tech) {
		super();
		this.city = city;
		this.tech = tech;
	}
	
	
}
